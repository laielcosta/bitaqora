<?php
// backend/recientes_api.php
session_start();
header('Content-Type: application/json; charset=utf-8');

// Incluye tu conexión sin modificar bbdd.php
require_once __DIR__ . '/bbdd.php';
$con = conectar();  // tu función conectar() devuelve mysqli

if (!$con) {
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo conectar con la BBDD']);
    exit;
}

// Recoge filtros
$usuario     = $_GET['usuario']    ?? '';
$proyecto    = $_GET['proyecto']   ?? '';
$tarea       = $_GET['tarea']      ?? '';
$etiqueta    = $_GET['etiqueta']   ?? '';
$descripcion = $_GET['descripcion'] ?? '';

// Construye condiciones de WHERE sobre la tabla registro
$conds = [];
if ($usuario !== '') {
    $u = mysqli_real_escape_string($con, $usuario);
    $conds[] = "r.id_usuario = '$u'";
}
if ($proyecto !== '') {
    $p = mysqli_real_escape_string($con, $proyecto);
    $conds[] = "r.id_proyecto = '$p'";
}
if ($tarea !== '') {
    $t = mysqli_real_escape_string($con, $tarea);
    $conds[] = "r.id_tarea = '$t'";
}
if ($etiqueta !== '') {
    $e = mysqli_real_escape_string($con, $etiqueta);
    $conds[] = "re.id_etiqueta = '$e'";
}
if ($descripcion !== '') {
    $d = mysqli_real_escape_string($con, $descripcion);
    $conds[] = "r.descripcion LIKE '%$d%'";
}
$where = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';

// Consulta principal: une registro con usuarios, proyectos, tareas y etiquetas
$sql = "
    SELECT
      u.nombre               AS usuario,
      p.nombre               AS proyecto,
      t.nombre               AS tarea,
      r.descripcion          AS descripcion,
      r.fecha                AS fecha,
      GROUP_CONCAT(e.nombre) AS etiquetas
    FROM registro r
    JOIN usuarios u            ON r.id_usuario  = u.id_usuario
    JOIN proyectos p           ON r.id_proyecto = p.id_proyecto
    JOIN tareas t              ON r.id_tarea    = t.id_tarea
    LEFT JOIN registro_etiquetas re ON r.id_registro = re.id_registro
    LEFT JOIN etiquetas e           ON re.id_etiqueta = e.id
    $where
    GROUP BY r.id_registro
    ORDER BY r.fecha DESC
";

$result = mysqli_query($con, $sql);
if (!$result) {
    http_response_code(500);
    echo json_encode(['error' => mysqli_error($con)]);
    exit;
}

// Construye el array de salida
$actividades = [];
while ($row = mysqli_fetch_assoc($result)) {
    $tags = [];
    if (!empty($row['etiquetas'])) {
        $tags = array_map('trim', explode(',', $row['etiquetas']));
    }
    $actividades[] = [
        'usuario'     => $row['usuario'],
        'proyecto'    => $row['proyecto'],
        'tarea'       => $row['tarea'],
        'descripcion' => $row['descripcion'],
        'fecha'       => $row['fecha'],
        'etiquetas'   => $tags
    ];
}

// Envía JSON al cliente
echo json_encode($actividades, JSON_UNESCAPED_UNICODE);

mysqli_close($con);
