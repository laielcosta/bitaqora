// js/recientes.js
const ENDPOINT_REC   = '../backend/recientes_api.php';
const listaRec       = document.getElementById('lista-actividades-recientes');
const filtroUsuario  = document.getElementById('filtro-usuario');
const filtroProyecto = document.getElementById('filtro-proyecto');
const filtroTarea    = document.getElementById('filtro-tarea');
const filtroEtiqueta = document.getElementById('filtro-etiqueta');
const filtroDesc     = document.getElementById('filtro-descripcion');
const btnFiltrar     = document.getElementById('btn-aplicar-filtros');

async function cargarOpciones(tipo, selectEl) {
  try {
    const res  = await fetch(`../backend/${tipo}_api.php`, { credentials: 'include' });
    const data = await res.json();
    const items = Array.isArray(data) ? data : (data[tipo] || []);

    selectEl.querySelectorAll('option:not(:first-child)').forEach(o => o.remove());

    const idKey = {
      usuarios:  'id_usuario',
      proyectos: 'id_proyecto',
      tareas:    'id_tarea',
      etiquetas: 'id'
    }[tipo];

    items.forEach(item => {
      const opt = document.createElement('option');
      opt.value = item[idKey];
      opt.textContent = item.nombre;
      selectEl.appendChild(opt);
    });
  } catch (e) {
    console.error(`Error cargando ${tipo}:`, e);
  }
}

async function actualizarRecientes() {
  try {
    const params = new URLSearchParams({
      usuario:    filtroUsuario.value,
      proyecto:   filtroProyecto.value,
      tarea:      filtroTarea.value,
      etiqueta:   filtroEtiqueta.value,
      descripcion:filtroDesc.value.trim()
    });

    const res  = await fetch(`${ENDPOINT_REC}?${params}`, { credentials: 'include' });
    const text = await res.text();               // → leemos TODO como texto

    console.log('RAW server response:', text);   // ← mira esto en la consola

    if (!res.ok) {
      console.error(`Servidor respondió ${res.status}`);
      throw new Error(`HTTP ${res.status}`);
    }

    const datos = JSON.parse(text);              // ahora parseamos

    listaRec.innerHTML = '';
    if (!Array.isArray(datos) || datos.length === 0) {
      listaRec.innerHTML = '<li style="text-align:center;">No se encontraron actividades</li>';
      return;
    }

    datos.forEach(act => {
      const li = document.createElement('li');
      li.innerHTML = `
        <strong>${act.usuario}</strong>
        – <em>${act.proyecto}</em>
        – ${act.tarea}
        – ${act.descripcion}
        – [${act.etiquetas.join(', ')}]
        – <small>${act.fecha}</small>
      `;
      listaRec.appendChild(li);
    });

  } catch (e) {
    console.error('Error al actualizar actividades:', e);
  }
}



document.addEventListener('DOMContentLoaded', () => {
  cargarOpciones('usuarios',   filtroUsuario);
  cargarOpciones('proyectos',  filtroProyecto);
  cargarOpciones('tareas',     filtroTarea);
  cargarOpciones('etiquetas',  filtroEtiqueta);

  btnFiltrar.addEventListener('click', actualizarRecientes);
  actualizarRecientes();
  setInterval(actualizarRecientes, 60000);
});
