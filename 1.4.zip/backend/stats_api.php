<?php
// stats_api.php – devuelve datos agregados según filtros dinámicos
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/bbdd.php';      // ajusta al nombre real de tu conexión PDO
session_start();

// ---------- 1. Control de sesión ------------------------------------------
if (!isset($_SESSION['id_usuario'])) {
  http_response_code(401);
  echo json_encode(['error'=>'No autenticado']);
  exit;
}

$uid  = $_SESSION['id_usuario'];
$tipo = $_SESSION['tipo'];              // 1 = admin

// ---------- 2. Parámetros GET ---------------------------------------------
$group = $_GET['group'] ?? 'estado';
$start = $_GET['start'] ?? date('Y-m-01');
$end   = $_GET['end']   ?? date('Y-m-d');
$live  = isset($_GET['live']);          // modo tiempo real

/* Validación básica */
$validGroups = ['estado','proyecto','tarea','day','month'];
if (!in_array($group, $validGroups, true)) {
  http_response_code(400);
  echo json_encode(['error'=>'Parámetro group inválido']);
  exit;
}

/* Si live=1 devolvemos sólo el total ≠ filtros de fecha */
if ($live) {
  $sql    = 'SELECT COUNT(*) AS total FROM registro';
  $params = [];
  if ($tipo != 1) {                     // filtra por usuario normal
    $sql   .= ' WHERE id_usuario = ?';
    $params = [$uid];
  }
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
  exit;
}

/* Filtros de fecha obligatorios */
$where  = 'fecha BETWEEN ? AND ?';
$params = [$start, $end];

/* Filtra por usuario para los no-admins */
if ($tipo != 1) {
  $where .= ' AND id_usuario = ?';
  $params[] = $uid;
}

/* ---------- 3. Query según agrupación ------------------------------------ */
switch ($group) {
  case 'estado':
    $sql = "SELECT estado AS label, COUNT(*) AS n
            FROM registro
            WHERE $where
            GROUP BY estado";
    break;

  case 'proyecto':
    if ($tipo != 1) {      // solo admin
      http_response_code(403); exit;
    }
    $sql = "SELECT p.nombre AS label, COUNT(*) AS n
            FROM registro r
            JOIN proyectos p ON p.id_proyecto = r.id_proyecto
            WHERE $where
            GROUP BY p.id_proyecto";
    break;

  case 'tarea':
    $sql = "SELECT t.nombre AS label, COUNT(*) AS n
            FROM registro r
            JOIN tareas t ON t.id_tarea = r.id_tarea
            WHERE $where
            GROUP BY t.id_tarea";
    break;

  case 'day':
    $sql = "SELECT DATE(fecha) AS label, COUNT(*) AS n
            FROM registro
            WHERE $where
            GROUP BY DATE(fecha)
            ORDER BY label";
    break;

  case 'month':
    $sql = "SELECT DATE_FORMAT(fecha,'%Y-%m') AS label, COUNT(*) AS n
            FROM registro
            WHERE $where
            GROUP BY DATE_FORMAT(fecha,'%Y-%m')
            ORDER BY label";
    break;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
