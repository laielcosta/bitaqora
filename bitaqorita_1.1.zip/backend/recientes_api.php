<?php
// recientes_api.php - Endpoint con filtros para historial completo de actividades
session_start();
// Validación de sesión de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['tipo'] != 1) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

header('Content-Type: application/json; charset=UTF-8');
include_once 'bbdd.php';
$conn = conectar();

// 1) Construir condiciones dinámicas
$conditions = [];

if (!empty($_GET['usuario'])) {
    $conditions[] = "r.id_usuario = " . intval($_GET['usuario']);
}
if (!empty($_GET['proyecto'])) {
    $conditions[] = "r.proyecto = " . intval($_GET['proyecto']);
}
if (!empty($_GET['tarea'])) {
    $conditions[] = "r.tarea = " . intval($_GET['tarea']);
}
if (!empty($_GET['descripcion'])) {
    $desc = $conn->real_escape_string(trim($_GET['descripcion']));
    $conditions[] = "r.descripcion LIKE '%{$desc}%'";
}

// 2) Preparamos el JOIN extra si vamos a filtrar por etiqueta
$joinEtiqueta = '';
if (!empty($_GET['etiqueta'])) {
    $et_id = intval($_GET['etiqueta']);
    $joinEtiqueta = "JOIN registro_etiquetas re ON r.id_registro = re.id_registro";
    $conditions[]  = "re.id_etiqueta = {$et_id}";
}

// 3) Montar la cláusula WHERE
$whereSQL = '';
if (count($conditions) > 0) {
    $whereSQL = 'WHERE ' . implode(' AND ', $conditions);
}

// 4) Consulta final
$sql = "
    SELECT 
      r.id_registro,
      u.nombre    AS usuario,
      p.nombre    AS proyecto,
      t.nombre    AS tarea,
      r.descripcion,
      DATE_FORMAT(r.fecha, '%Y-%m-%d %H:%i:%s') AS fecha
    FROM registro r
    JOIN usuarios  u ON r.id_usuario = u.id_usuario
    JOIN proyectos p ON r.proyecto   = p.id_proyecto
    JOIN tareas    t ON r.tarea      = t.id_tarea
    {$joinEtiqueta}
    {$whereSQL}
    ORDER BY r.fecha DESC
    LIMIT 100
";

// 5) Ejecutar y devolver
$result     = $conn->query($sql);
$activities = [];
while ($row = $result->fetch_assoc()) {
    $activities[] = $row;
}

echo json_encode($activities);
$conn->close();
