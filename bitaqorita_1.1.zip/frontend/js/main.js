import { getSessionStatus, login } from './api.js';

document.addEventListener('DOMContentLoaded', async () => {
  const saludoAdmin = document.getElementById('saludoAdmin');
  const saludoUsuario = document.getElementById('saludoUsuario');
  const contAdmin = document.getElementById('contenidoAdmin');
  const contUsuario = document.getElementById('contenidoUsuario');
  const loginContainer = document.getElementById('loginContainer');
  const loginForm = document.getElementById('loginForm');

  try {
    const data = await getSessionStatus();

    // Si estamos en login.html
    const isLoginPage = window.location.pathname.includes('login.html');

    if (isLoginPage) {
      if (data.autenticado) {
        // Redirigir automáticamente al panel correcto
        if (data.tipo == 1) window.location.href = 'admin.html';
        else window.location.href = 'usuario.html';
        return;
      }

      // Mostrar el formulario
      if (loginContainer) loginContainer.style.display = 'block';

      // Manejar el envío del formulario
      if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
          e.preventDefault();
          const usuario = document.getElementById('usuario').value;
          const password = document.getElementById('password').value;

          const result = await login(usuario, password);

          if (result.success) {
            if (result.tipo == 1) window.location.href = 'admin.html';
            else window.location.href = 'usuario.html';
          } else {
            alert(result.mensaje);
          }
        });
      }

      return; // Detener aquí para no ejecutar lo demás
    }

    // Si estamos en otras páginas, verificar tipo y mostrar
    if (data.autenticado) {
      if (saludoAdmin && data.tipo == 1) {
        saludoAdmin.textContent = `¡Hola ${data.usuario}! ¿Qué quieres hacer hoy?`;
        contAdmin.style.display = 'block';
      } else if (saludoUsuario && data.tipo == 0) {
       /* await cargarHeaderEstatico(data.tipo, data.usuario);*/
        saludoUsuario.textContent = `¡Hola ${data.usuario}! ¿Qué quieres hacer hoy?`;
        contUsuario.style.display = 'block';
      } else {
        // Usuario intentando acceder al panel que no le toca
        if (data.tipo == 1) window.location.href = 'admin.html';
        else window.location.href = 'usuario.html';
      }
    } else {
      // No autenticado, redirigir a login
      window.location.href = 'login.html';
    }

  } catch (err) {
    console.error(err);
    alert('Error al verificar sesión');
  }
});
