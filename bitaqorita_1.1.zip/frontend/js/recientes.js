// recientes.js - Panel de actividades con filtros usando mapeo de IDs y manejo de respuesta para tareas
const ENDPOINT_REC   = '../backend/recientes_api.php';
const listaRec       = document.getElementById('lista-actividades-recientes');
const filtroUsuario  = document.getElementById('filtro-usuario');
const filtroProyecto = document.getElementById('filtro-proyecto');
const filtroTarea    = document.getElementById('filtro-tarea');
const filtroDesc     = document.getElementById('filtro-descripcion');
const btnFiltrar     = document.getElementById('btn-aplicar-filtros');
const filtroEtiqueta = document.getElementById('filtro-etiqueta');

// Mapeo de claves de ID según endpoint
const idKeys = {
  usuarios:  'id_usuario',
  proyectos: 'id_proyecto',
  tareas:    'id_tarea',
  etiquetas: 'id'
};

/**
 * Carga opciones en un <select> consumiendo el API correspondiente
 */
async function cargarOpciones(tipo, selectEl) {
  try {
    const res = await fetch(`../backend/${tipo}_api.php`, { credentials: 'include' });
    if (!res.ok) throw new Error(`Error al cargar ${tipo}: HTTP ${res.status}`);
    const data = await res.json();

    // Determinar array de ítems: la API de tareas devuelve { tareas: [...] }, 
    // mientras que usuarios y proyectos devuelven directamente arrays.
    const items = Array.isArray(data)
      ? data
      : Array.isArray(data[tipo])
        ? data[tipo]
        : [];

    // Limpiar opciones previas (excepto la primera)
    selectEl.querySelectorAll('option:not(:first-child)').forEach(o => o.remove());

    const key = idKeys[tipo];
    items.forEach(item => {
      if (!(key in item)) return;
      const opt = document.createElement('option');
      opt.value = item[key];
      opt.textContent = item.nombre;
      selectEl.appendChild(opt);
    });
  } catch (err) {
    console.error(`Error en cargarOpciones(${tipo}):`, err);
  }
}

/**
 * Recupera y muestra las actividades según filtros actuales
 */
async function actualizarRecientes() {
  try {
    const params = new URLSearchParams({
      usuario:    filtroUsuario.value,
      proyecto:   filtroProyecto.value,
      tarea:      filtroTarea.value,
      etiqueta:    filtroEtiqueta.value,
      descripcion: filtroDesc.value.trim()
    });
    const res = await fetch(`${ENDPOINT_REC}?${params}`, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const datos = await res.json();
    listaRec.innerHTML = '';
    if (!Array.isArray(datos) || datos.length === 0) {
      listaRec.innerHTML = '<li>No se encontraron actividades</li>';
      return;
    }

    datos.forEach(act => {
      const li = document.createElement('li');
      li.textContent = `[${act.fecha}] ${act.usuario} → ${act.proyecto} / ${act.tarea}: ${act.descripcion}`;
      listaRec.appendChild(li);
    });
  } catch (e) {
    console.error('Error al actualizar actividades:', e);
  }
}

// Inicialización: carga selects, enlaza botón y arranca refresco periódico
document.addEventListener('DOMContentLoaded', () => {
  if (!listaRec) {
    console.error('Elemento #lista-actividades-recientes no encontrado.');
    return;
  }

  cargarOpciones('usuarios', filtroUsuario);
  cargarOpciones('proyectos', filtroProyecto);
  cargarOpciones('tareas', filtroTarea);
  cargarOpciones('etiquetas', filtroEtiqueta);

  btnFiltrar.addEventListener('click', actualizarRecientes);

  // Ejecución inicial y refresco cada 5 segundos
  actualizarRecientes();
  setInterval(actualizarRecientes, 60000);
});
