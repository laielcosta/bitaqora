/* stats.js – panel único con filtros dinámicos */

import { Chart, registerables } from 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.esm.js';
import streamingPlugin from 'https://cdn.jsdelivr.net/npm/chartjs-plugin-streaming@3.0.0-rc.1/dist/chartjs-plugin-streaming.esm.js';

Chart.register(...registerables, streamingPlugin);

/* --- Elementos DOM ------------------------------------------------------ */
const $ = sel => document.querySelector(sel);
const ctx = $('#grafico');
const fInicio = $('#fInicio');
const fFin    = $('#fFin');
const selGroup = $('#selGroup');
const chkLive  = $('#chkLive');

/* --- Gráfico base -------------------------------------------------------- */
const chart = new Chart(ctx, {
  type   : 'bar',
  data   : { labels: [], datasets: [{ label:'', data:[] }] },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    scales : { x:{ type:'category' }, y:{ beginAtZero:true, precision:0 } },
    plugins: { legend:{ display:false } }
  }
});

/* --- Helpers ------------------------------------------------------------- */
function hoy() { return new Date().toISOString().slice(0,10); }

/* URLs con filtros actuales */
function buildURL () {
  const p = new URLSearchParams({
    group : selGroup.value,
    start : fInicio.value,
    end   : fFin.value
  });
  if (chkLive.checked) p.append('live','1');
  return `/backend/stats_api.php?${p.toString()}`;
}

/* Cambia el tipo de eje X si estamos en modo tiempo real */
function ensureRealtime (on) {
  const isRT = chart.options.scales.x.type === 'realtime';
  if (on && !isRT) {
    chart.options.scales.x.type = 'realtime';
    chart.data.labels  = [];
    chart.data.datasets[0].data = [];
  } else if (!on && isRT) {
    chart.options.scales.x.type = 'category';
  }
}

/* Carga datos y actualiza el gráfico */
async function updateChart () {
  try {
    ensureRealtime(chkLive.checked);
    const res  = await fetch(buildURL(), { credentials:'include' });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`HTTP ${res.status}: ${text.slice(0,200)}`);
    }(await res.text());
    const json = await res.json();

    if (chkLive.checked) {
      // json = { total: 123 }
      chart.data.datasets[0].label = 'Total de registros';
      chart.data.datasets[0].data.push({ x: Date.now(), y: json.total });
    } else {
      // json = [{label:'Pending', n:5}, …]
      chart.data.labels            = json.map(r => r.label);
      chart.data.datasets[0].label = `Agrupado por ${selGroup.value}`;
      chart.data.datasets[0].data  = json.map(r => r.n);
    }
    chart.update('none');
  } catch (err) {
    console.error('stats.js:', err);
  }
}

/* Reinicia fechas al primer día del mes hasta hoy */
function initDates () {
  const d = new Date();
  fInicio.value = d.toISOString().slice(0,8) + '01';
  fFin.value    = hoy();
}

/* --- Evento de sesión desde <app-header> --------------------------------- */
document.querySelector('app-header')
  .addEventListener('session-ready', e => {
    const { tipo } = e.detail;                // 1 = admin

    // Si NO es admin, quita "proyecto" y el modo Live
    if (tipo !== 1) {
      $('#selGroup option[value="proyecto"]').disabled = true;
      chkLive.checked = false;
      chkLive.parentElement.style.display = 'none';
    }

    initDates();
    updateChart();
  });

/* --- Listeners de filtros ------------------------------------------------ */
[fInicio, fFin, selGroup, chkLive]
  .forEach(el => el.addEventListener('change', updateChart));
